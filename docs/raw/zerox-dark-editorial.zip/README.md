# zerox-dark-editorial

基于 `guide-dark-editorial-system.html` 重写的深色技术编辑部设计系统。它的识别度来自排版张力、12 栏结构、细规则线和单一主强调色，而不是背景纹理、渐变或通用 SaaS 仪表盘组件。当前版本的按钮与响应式背景遵循“Originkit mechanism preserved, editorial skin applied”：保留 Originkit 的可迁移实现机制，再用本系统的 ink/paper/signal/data 肤色化。

## Originkit 原始参考地址

这些链接是按钮动效与响应式背景的代码机制来源，用于校准 motion 原味；它们不是视觉风格替代品。生成页面时仍必须遵守 zerox-dark-editorial 的 ink/paper/signal/data、直角、细线、低明度表面、12 栏编辑网格和单一克制荧光绿主强调规则。

- `key-cap-button`：https://www.originkit.dev/components/keycap-button?preset=base
- `dotted-offset-button`：https://www.originkit.dev/components/dotted-offset-button?preset=base
- `light-glass-button`：https://www.originkit.dev/components/light-glass-button?preset=base
- `radial-reveal-button`：https://www.originkit.dev/components/radial-reveal-button?preset=base
- `tactile-button`：https://www.originkit.dev/components/tactile-button?preset=base
- `cube-flip-button`：https://www.originkit.dev/components/cube-flip-button
- `kinetic-grid`：https://www.originkit.dev/components/kineticgrid?preset=base

## 核心原则

1. 内容先于容器：先建立标题、导语、正文、注记与证据的关系，再选择组件。
2. 克制的高密度：允许信息密集，但必须用字号、留白、细线和网格建立秩序。
3. 颜色必须有语义：`--signal-green #3dff92` 是唯一持续克制荧光绿主强调；`--signal-orange` 仅作为 legacy alias 映射到荧光绿；`--data-cyan`、`--success-green`、`--caution-yellow`、`--danger-red` 只表达数据或状态。
4. 让结构可见：编号、边线、标签、栏宽和坐标感是主要视觉语言。
5. 交付验收：移除背景纹理和所有强调色后，页面仍应仅凭字级、网格与间距保持清晰层级。

## 视觉基础

### 色彩

- 基础色：`--ink-950 #08110f`、`--ink-900 #0d1816`、`--ink-850 #13221f`。
- 文本色：`--paper-100 #e8e9df` 用于标题和主正文；`--paper-300 #c8cbc1` 用于次级正文。
- 辅助线和元信息：`--muted-500 #8d9c98`、`--line-700 #2a3c3a`。
- 主强调：`--signal-green #3dff92` 克制荧光科技绿主强调，用于导航、进度、当前状态、决策强调；`--signal-orange` 为 legacy alias，已映射到 `--signal-green`。
- 数据/状态：`--data-cyan #35c9d0` 更冷、更安静地承载信息；`--success-green #8bd79f` 更柔和、更低饱和；`--caution-yellow #d8c75e`、`--danger-red #d67875` 继续保持低饱和语义区分。

### 字体

- 标题与观点：`--serif "Songti SC","Noto Serif CJK SC","Source Han Serif SC","STSong",serif`。
- 正文与解释：`--sans "PingFang SC","Noto Sans CJK SC","Microsoft YaHei",sans-serif`。
- 标签、编号、代码与状态：`--mono "SFMono-Regular","Cascadia Code","Roboto Mono","Noto Sans Mono CJK SC",monospace`。

关键字级：

- H1：`clamp(64px,10.2vw,148px) / .82`，衬线，`letter-spacing:-0.075em`，允许描边字。
- H2：`clamp(42px,6vw,76px) / .98`，衬线。
- Lead：`clamp(24px,3.3vw,42px) / 1.45`，衬线。
- Body：`16px / 1.78`，无衬线。
- Label：`10-12px`，等宽，大写，字距 `0.08-0.16em`。

### 版式

- 最大内容宽度：`1240px`。
- 页边距：`32px`。
- 章节间距：`112px`。
- 网格：12 栏编辑网格，核心结构为 `2/8/2`、`7/5`、`8/4`、`6/6`、`12/full`。

### 动效

- Kinetic Grid：仅用于背景动效系统。UIKit 页面使用 canvas、`requestAnimationFrame`、`ResizeObserver`、devicePixelRatio scaling、pointer/touch tracking、mesh lines、home force、velocity damping 与 cursor trail。
- 页面进场：`opacity + translateY(18px)`，约 `650ms`。
- 交互反馈：`200-250ms`。
- 禁止无意义的持续动画；必须支持 `prefers-reduced-motion`，低动效时网格保持静态。

## Button Motion Grammar

Button 的动效不是装饰库，而是操作语义的语法。所有变体仍然遵守 ink/paper/signal/data、直角、细线、低明度表面、mono 小标签与单一克制荧光绿主强调。代码层面保留 Originkit 原味机制；不要直接复制 minified React 模块，应该转译为设计系统 CSS/JS 约束。

1. `key-cap-button`：用于命令型按钮、快捷键感操作、技术控制台入口，例如“执行验证 / 运行检查 / 打开命令”。结构必须包含隐藏 in-flow sizer、absolute prism、`transform-style: preserve-3d`、`translateZ`、`rotateX(49deg)`、`rotateZ(-37deg)`；保留 15px prism depth、8px rest float、7px hoverFloat 微收缩与快速 press active progress。顶面使用 paper，棱柱使用 ink，反射与细底光使用 signal-green 克制荧光绿。DesignPass.dev / Ernest Liu 的 keycap 原始实现为 MIT 授权，本系统为机制派生与肤色化。
2. `dotted-offset-button`：用于目录切换、筛选、章节索引、当前/默认状态切换。hover 必须让 face 移动 `x:-14px y:-14px`，同时写入 `box-shadow: 14px 14px 0`；默认可使用 40px 64px 的 Originkit 大尺寸，密集 UI 才使用 `compact` 4px 子变体。背板使用 data-cyan 点阵或 line 虚线。
3. `light-glass-button`：用于 hero 背景或 kinetic grid 上的高级入口，只允许少量使用。必须用 JS pointermove 写入 `--mx`/`--my`，保留 `backdrop-filter: blur() saturate() brightness()`、radial light、conic edge flare 与 `mask-composite: exclude` / `-webkit-mask-composite: xor`；不能退化成纯 hover 静态光。
4. `radial-reveal-button`：用于单一高意图 CTA，例如“进入系统 / 查看规则 / 阅读全文”。必须根据 pointer position 计算 `clip-path: circle(r% at x% y%)`，进入从光标位置揭示，离开反向收束；默认 450ms ease-in-out。不要固定中心 reveal，也不要用 `scale()` 替代。
5. `tactile-button`：用于主操作、确认执行和需要实体按压反馈的按钮。结构必须包含 absolute base plate，默认 base offset 保留 `-1px, 11px`；face 在 pointerdown 下压到底板。Originkit 原始 tactile base #FC731C 机制保留，颜色已映射到 signal-green，face 使用 ink/paper；不要简化为普通 `translateY(2px)`。
6. `cube-flip-button`：用于双态/结果预告，例如“查看证据 / 显示结论”、“复制令牌 / 已复制”。必须使用 `perspective:600px`、front/back labels、`transform-style: preserve-3d`、front/back 面与 90° cube rotation；默认 direction down，可按语义映射 up/down/left/right。

### Kinetic responsive grid

UIKit 背景必须使用 Originkit kineticgrid 结构：canvas + `requestAnimationFrame` loop + `ResizeObserver` + devicePixelRatio scaling。默认参数保持 spacing 50、radius 200、strength 4、trail on；每个 grid point 保存 home 坐标 `hx/hy`，每帧用 `(hx - x) * .08` / `(hy - y) * .08` 回家，鼠标激活时在半径内 attraction，velocity damping `.82`。line alpha 约 `.14`、width `.75`；trail 最多 80 点并在 260ms 内淡出。颜色映射为 ink background、paper dots、data-cyan lines、signal-green 克制荧光绿 trail。

低动效环境下必须停止位移、3D 翻转和光标追踪，只保留颜色、边框和文案状态。

## 组件

| Component | Preview | Contract | Key Insight |
|---|---|---|---|
| Button | `preview/component-button.html` | `components/button.json` | 基础态保持透明描边/当前反转/单一克制荧光绿主强调，动效只服务操作语义。 |
| Tag | `preview/component-tag.html` | `components/tag.json` | 标签必须传递来源、状态或证据类型，不做装饰贴纸。 |
| Flow | `preview/component-flow.html` | `components/flow.json` | 步骤描边块配克制荧光绿方向符号，表达路径而非表演。 |
| Data Table | `preview/component-data-table.html` | `components/data-table.json` | 全宽高密度表格，以水平线和等宽表头组织信息。 |
| Callout | `preview/component-callout.html` | `components/callout.json` | 使用 2/8/2 网格和克制荧光绿规则线强调一个可执行结论。 |
| Editorial Card | `preview/component-editorial-card.html` | `components/editorial-card.json` | 卡片是编辑版面块，不是通用圆角卡片。 |

## 文件索引

- `colors_and_type.css` — 颜色、字体、间距、尺寸、圆角、阴影、动效与版式 token。
- `components/index.json` — 当前组件索引。
- `components/*.json` — 组件合同。
- `preview/component-*.html` — 组件预览。
- `ui_kits/website/index.html` — React 18 网站 UIKit，包含 kinetic grid。
- `library-consumption.json` — 推荐读取顺序。
