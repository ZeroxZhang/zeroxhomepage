---
name: zerox-dark-editorial
description: Use this design system to create dark technical editorial pages with strict grid hierarchy, restrained density, single restrained neon green signal emphasis, Originkit-preserved button motion, and kinetic responsive grid background motion.
user-invocable: true
---

# zerox-dark-editorial Design System

先阅读 `README.md`、`colors_and_type.css`、`components/index.json`，再使用组件合同与预览页。

## 必守视觉规则

- 默认深色体验：`--ink-950 #08110f` 是页面底色，`--ink-900 #0d1816` 与 `--ink-850 #13221f` 是低明度表面。
- 主文字使用 `--paper-100 #e8e9df`，次级文字使用 `--paper-300 #c8cbc1`，辅助信息使用 `--muted-500 #8d9c98`。
- 唯一持续主强调色是 `--signal-green #3dff92` 克制荧光绿主强调，用于导航、进度、当前状态、决策强调；`--signal-orange` 是 legacy alias，已映射到荧光绿。不要使用蓝色作为主色。
- `--data-cyan #35c9d0` 只用于数据/信息，视觉上更冷、更安静；`--success-green #8bd79f` 更柔和、更低饱和，`--caution-yellow`、`--danger-red` 只用于状态语义。
- 字体分工：衬线负责观点，无衬线负责解释，等宽负责系统状态。
- 页面最大内容宽度 `1240px`，页边距 `32px`，章节间距 `112px`，使用 12 栏编辑网格。
- 核心结构：`2/8/2`、`7/5`、`8/4`、`6/6`、`12/full`。
- 组件语言：直角、细线、低明度表面；组件依靠结构与状态变化获得可用性。
- 卡片不是通用圆角卡片，而是 `editorial-card` 编辑版面块。
- 交付验收：移除背景纹理和所有强调色后，页面仍应仅凭字级、网格与间距保持清晰层级。

## 动效规则

- 当前动效原则是 “Originkit mechanism preserved, editorial skin applied”：保留 Originkit 的关键实现机制，只替换为 ink/paper/signal/data 肤色。
- Kinetic grid 只用于背景动效系统，不用于按钮、标签或普通卡片装饰。
- 背景网格必须使用 canvas、`requestAnimationFrame` loop、`ResizeObserver`、devicePixelRatio scaling、mousemove/touchmove/touchend/mouseleave listeners、mesh lines、home force、velocity damping `.82` 和最多 80 点的 260ms cursor trail。
- Kinetic grid 参数默认保持 spacing 50、radius 200、strength 4；颜色映射为 ink background、paper dots、data-cyan lines、signal-green 克制荧光绿 trail。
- 低动效偏好时停止动画，呈现静态网格。
- 页面进场只使用 `opacity + translateY(18px)`，约 `650ms`。
- 交互反馈控制在 `200-250ms`，避免无意义的持续动画。
- Button motion 必须按语义选用：`key-cap` 表示命令/快捷键，`dotted-offset` 表示目录或筛选切换，`light-glass` 只用于 hero/kinetic grid 高级入口，`radial-reveal` 只用于单一高意图 CTA，`tactile` 用于主操作或确认执行，`cube-flip` 只用于双态/结果预告。
- `key-cap` 必须保留隐藏 sizer、absolute prism、`preserve-3d`、`translateZ`、49°/-37° 相机、15px depth、hover float 微收缩和快速 press active progress。
- `dotted-offset` 必须保留 14px 原味 offset 与同值 box-shadow；密集 UI 才使用 4px compact 子变体。
- `light-glass` 必须用 JS cursor tracking 写入 `--mx`/`--my`，并保留 radial light、conic edge flare 与 exclude/xor mask。
- `radial-reveal` 必须从 pointer origin 计算 `clip-path: circle(r% at x% y%)`，不使用固定中心或 `scale()`。
- `tactile` 必须保留 absolute base plate translate(-1px, 11px) 与 face 下压。
- `cube-flip` 必须保留 perspective 600、front/back labels、preserve-3d 与 90° rotation，仅用于双态语义。
- Button motion 不得改变核心视觉语言：直角、细线、低明度表面、mono 小标签、单一克制荧光绿主强调；不要做圆胖键帽、泛 SaaS 发光、过度 3D 或无语义翻转。
- 所有 button motion 必须支持 `prefers-reduced-motion`：低动效时停止位移、3D 翻转、径向扩张、press travel 和光标追踪，保留颜色、边框与文案状态。

### Source References / 原始参考地址

使用以下 Originkit 原始地址校准 motion 原味；这些 URL 只作为代码机制来源，不替代本设计系统的视觉规则。后续 Agent 必须继续遵守 zerox-dark-editorial 的 ink/paper/signal/data、直角、细线、低明度表面、mono 小标签、12 栏编辑网格与单一 `--signal-green` 克制荧光绿主强调。Originkit 原始 tactile base #FC731C 机制保留，颜色已映射到 signal-green。

- `key-cap-button` → `btn-keycap`：https://www.originkit.dev/components/keycap-button?preset=base
- `dotted-offset-button` → `btn-dotted-offset`：https://www.originkit.dev/components/dotted-offset-button?preset=base
- `light-glass-button` → `btn-light-glass`：https://www.originkit.dev/components/light-glass-button?preset=base
- `radial-reveal-button` → `btn-radial-reveal`：https://www.originkit.dev/components/radial-reveal-button?preset=base
- `tactile-button` → `btn-tactile`：https://www.originkit.dev/components/tactile-button?preset=base
- `cube-flip-button` → `btn-cube-flip`：https://www.originkit.dev/components/cube-flip-button
- `kinetic-grid` → `KineticGrid`：https://www.originkit.dev/components/kineticgrid?preset=base

## 当前组件面

- `button`
- `tag`
- `flow`
- `data-table`
- `callout`
- `editorial-card`

## 推荐读取顺序

1. `colors_and_type.css`
2. `components/index.json`
3. 当前需要的 `components/{slug}.json`
4. 对应 `preview/component-{slug}.html`
5. `ui_kits/website/index.html`
